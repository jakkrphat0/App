# MoneyTrack (Android) — สร้าง APK ด้วย GitHub จากมือถือ

1. สมัคร/ล็อกอิน github.com แล้วสร้าง Repository ใหม่ (New repository)
2. Add file → Upload files → เลือกไฟล์ `moneytrack-src.zip` ไฟล์เดียว (ไม่ต้องแตกซิป) → Commit
3. Add file → Create new file → ตั้งชื่อ `.github/workflows/build.yml` → วางเนื้อหาจากไฟล์ `build.yml` → Commit
4. แท็บ Actions → รอ workflow "Build APK" ขึ้นเครื่องหมายถูกสีเขียว (ประมาณ 5-10 นาที)
5. เปิดการรันนั้น เลื่อนลงหัวข้อ Artifacts → ดาวน์โหลด `MoneyTrack-APK` (เป็นซิป แตกแล้วได้ app-debug.apk) → ติดตั้งในมือถือ

ถ้าสร้างไม่ผ่าน เปิดขั้นตอนที่ขึ้นสีแดงใน Actions แล้วส่งข้อความ error มาให้ดู

## ตั้งค่าก่อนสร้าง (ไม่บังคับ)
แก้ `app/src/main/java/com/example/moneytrack/Config.kt` ให้ตรงกับธนาคารของคุณ

## ใช้งาน
- กด "เปิดสิทธิ์อ่านการแจ้งเตือน" แล้วเปิดให้แอปนี้
- Gmail: เปิดยืนยัน 2 ขั้นตอน แล้วสร้าง App Password ที่ myaccount.google.com/apppasswords ใส่ในแอป
- แตะชื่อบัญชีเพื่อตั้งยอดตั้งต้น
- แอปไม่อ่านอีเมลย้อนหลัง นับตั้งแต่บันทึกการตั้งค่าอีเมล และเช็กอีเมลใหม่ทุกครั้งที่เปิดแอป
- Krungsri รับเฉพาะรายจ่ายจากอีเมล รายรับกดปุ่ม "＋ เพิ่มรายรับ"
- สีและรูปพื้นหลังแยกตามบัญชี ปุ่ม "ปรับแต่งหน้าตา"

## ข้อจำกัด
- LINE: อ่านได้เฉพาะข้อความที่ขึ้นเป็นการแจ้งเตือนหลังติดตั้ง
- รหัสผ่านอีเมลเก็บใน SharedPreferences ธรรมดา ถ้าใช้จริงควรเปลี่ยนเป็น EncryptedSharedPreferences
- APK เป็นแบบ debug ติดตั้งใช้เองได้ แต่ Play Protect อาจเตือน
