package com.example.moneytrack

import java.util.GregorianCalendar

data class Parsed(val type: String, val amt: Double, val ref: String, val note: String = "", val time: Long? = null)

object Parser {
    private val amtRe = Regex("""([0-9][0-9,]*(?:\.[0-9]{1,2})?)\s*(?:บาท|THB|฿)""", RegexOption.IGNORE_CASE)
    private val refRe = Regex(
        """(?:เลข(?:ที่)?อ้างอิง|รหัสอ้างอิง|ref(?:erence)?(?:\s*(?:no|number|id))?)\.?\s*[:：#]?\s*([A-Za-z0-9]{6,})""",
        RegexOption.IGNORE_CASE
    )
    private val inc = Regex("เงินเข้า|รับเงิน|ได้รับ|ฝาก|received|deposit|credit", RegexOption.IGNORE_CASE)
    private val exp = Regex("เงินออก|ถอน|โอนเงินออก|โอนเงินไป|โอนไป|ชำระ|จ่าย|ซื้อ|หักบัญชี|payment|withdraw|debit|purchase|transfer", RegexOption.IGNORE_CASE)
    private val balWord = Regex("คงเหลือ|balance|ยอดเงิน", RegexOption.IGNORE_CASE)

    // อีเมล Krungsri: แต่ละบรรทัดเป็น "ชื่อช่อง: ค่า"
    private val kAmt = Regex("""จำนวนเงิน\s*\(บาท\)\s*[:：]?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""")
    private val kRef = Regex("""หมายเลขอ้างอิง\s*[:：]?\s*([A-Za-z0-9]{6,})""")
    private val kTime = Regex("""วัน-เวลาที่ทำรายการ\s*[:：]?\s*(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?""")
    private val kPayee = Regex("""ผู้รับ(?:ชำระ)?เงิน\s*[:：]?\s*(.+?)\s*จำนวนเงิน""")
    private val kIn = Regex("เข้าบัญชี|รับเงิน|ฝากเข้า")

    fun parse(raw: String): Parsed? {
        val s = raw.replace(Regex("\\s+"), " ")
        return parseLabeled(s) ?: parseGeneric(s)
    }

    private fun parseLabeled(s: String): Parsed? {
        val a = kAmt.find(s) ?: return null
        if (s.contains("ผลการทำรายการ") && !s.contains("สำเร็จ")) return null
        val amt = a.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        if (amt <= 0) return null
        val type = when {
            s.contains("หักจากบัญชี") -> "exp"
            kIn.containsMatchIn(s) -> "inc"
            else -> return null
        }
        val t = kTime.find(s)?.let {
            val g = it.groupValues
            var y = g[3].toInt(); if (y > 2400) y -= 543
            GregorianCalendar(y, g[2].toInt() - 1, g[1].toInt(), g[4].toInt(), g[5].toInt(), g[6].ifEmpty { "0" }.toInt()).timeInMillis
        }
        return Parsed(type, amt, kRef.find(s)?.groupValues?.get(1) ?: "", kPayee.find(s)?.groupValues?.get(1)?.trim()?.take(40) ?: "", t)
    }

    private fun parseGeneric(s: String): Parsed? {
        // เลือกจำนวนเงินแรกที่ไม่ใช่ "ยอดคงเหลือ"
        val m = amtRe.findAll(s).firstOrNull { !balWord.containsMatchIn(s.substring(maxOf(0, it.range.first - 14), it.range.first)) }
            ?: return null
        val amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        if (amt <= 0) return null
        val i = inc.find(s)?.range?.first
        val e = exp.find(s)?.range?.first
        val type = when {
            i != null && (e == null || i < e) -> "inc"
            e != null -> "exp"
            else -> return null
        }
        return Parsed(type, amt, refRe.find(s)?.groupValues?.get(1) ?: "")
    }
}
