package com.example.moneytrack

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var bgView: ImageView
    private val sp by lazy { getSharedPreferences("money", MODE_PRIVATE) }
    private val colors = listOf(
        "เขียว" to 0xFF0F8A5F.toInt(), "น้ำเงิน" to 0xFF1A73E8.toInt(), "ม่วง" to 0xFF8E44AD.toInt(),
        "ส้ม" to 0xFFE67E22.toInt(), "แดง" to 0xFFD6453D.toInt(), "ชมพู" to 0xFFE84393.toInt()
    )
    // หน้าตาแยกตามบัญชี: สีและรูปพื้นหลังของแต่ละบัญชีเก็บแยกกัน
    private val cur: String get() = sp.getString("cur", Config.accounts[0].id) ?: Config.accounts[0].id
    private fun accOf(id: String) = sp.getInt("acc_$id", colors[0].second)
    private fun bgFile(id: String) = File(filesDir, "bg_$id.jpg")

    // เลือกรูปพื้นหลังจากคลังภาพ แล้วย่อเก็บไว้ในแอป
    private val pickBg = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            val o = BitmapFactory.Options().apply { inSampleSize = 4 }
            val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, o) }!!
            FileOutputStream(bgFile(cur)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            draw()
        } catch (e: Exception) {
            Toast.makeText(this, "ใช้รูปนี้ไม่ได้", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFFF4F6F5.toInt()) }
        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(bgView, ViewGroup.LayoutParams(-1, -1))
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        frame.addView(ScrollView(this).apply { addView(root) }, ViewGroup.LayoutParams(-1, -1))
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume(); draw()
        Config.accounts.filter { it.mailFrom.isNotEmpty() }.forEach { syncMail(it, false) }
    }

    private fun tv(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(0xFF16211C.toInt()); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24)
        background = GradientDrawable().apply { setColor(0xE6FFFFFF.toInt()); cornerRadius = 32f }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 16, 0, 16) }
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); backgroundTintList = ColorStateList.valueOf(accOf(cur)); setOnClickListener { f() }
    }

    private fun ask(title: String, hint: String, pw: Boolean = false, num: Boolean = false, cb: (String) -> Unit) {
        val e = EditText(this); e.hint = hint
        if (pw) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (num) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("ตกลง") { _, _ -> cb(e.text.toString().trim()) }
            .setNegativeButton("ยกเลิก", null).show()
    }

    private fun customize() {
        AlertDialog.Builder(this).setTitle("ปรับแต่งหน้าตา: " + Config.accounts.first { it.id == cur }.name)
            .setItems(arrayOf("เปลี่ยนสีหลัก", "เลือกรูปพื้นหลัง", "ลบรูปพื้นหลัง")) { _, i ->
                when (i) {
                    0 -> AlertDialog.Builder(this).setTitle("เลือกสี")
                        .setItems(colors.map { it.first }.toTypedArray()) { _, j ->
                            sp.edit().putInt("acc_$cur", colors[j].second).apply(); draw()
                        }.show()
                    1 -> pickBg.launch("image/*")
                    2 -> { bgFile(cur).delete(); draw() }
                }
            }.show()
    }

    // เพิ่มรายรับเอง (บันทึกเวลาปัจจุบัน)
    private fun addIncome(a: Acct) {
        ask("จำนวนเงินรายรับ", "บาท", num = true) { v ->
            val amt = v.toDoubleOrNull()
            if (amt == null || amt <= 0) { Toast.makeText(this, "จำนวนเงินไม่ถูกต้อง", Toast.LENGTH_SHORT).show(); return@ask }
            ask("บันทึก (ไม่บังคับ)", "เช่น เงินเดือน") { n ->
                Store.add(this, a.id, "inc", amt, n.ifEmpty { "รายรับ" }, "", System.currentTimeMillis()); draw()
            }
        }
    }

    // ดึงเฉพาะอีเมลใหม่ (ไม่ย้อนหลัง)
    private fun syncMail(a: Acct, toast: Boolean) {
        Thread {
            val n = try { MailSync.sync(this, a) } catch (e: Exception) { -1 }
            runOnUiThread {
                if (toast || n > 0) Toast.makeText(this, if (n < 0) "เชื่อมอีเมลไม่สำเร็จ" else "เพิ่ม $n รายการ", Toast.LENGTH_LONG).show()
                if (n > 0) draw()
            }
        }.start()
    }

    private fun draw() {
        root.removeAllViews()
        val bf = bgFile(cur)
        if (bf.exists()) bgView.setImageBitmap(BitmapFactory.decodeFile(bf.path)) else bgView.setImageDrawable(null)

        // แถบสลับบัญชี
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (x in Config.accounts) bar.addView(Button(this).apply {
            text = x.name; setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(accOf(x.id))
            alpha = if (x.id == cur) 1f else 0.55f
            setOnClickListener { sp.edit().putString("cur", x.id).apply(); draw() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar)


        // วันที่และเวลาตามเวลาที่แจ้งเตือนเข้ามา (ปี พ.ศ.)
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("th", "TH"))
        for (a in Config.accounts.filter { it.id == cur }) {
            val p = panel()
            p.addView(tv(a.name, 20f, true).apply {
                setOnClickListener { ask("ยอดตั้งต้น", "บาท", num = true) { v -> Store.setOpen(this@MainActivity, a.id, v.toDoubleOrNull() ?: 0.0); draw() } }
            })
            p.addView(tv(String.format("คงเหลือ ฿%,.2f  (แตะชื่อบัญชีเพื่อตั้งยอดตั้งต้น)", Store.balance(this@MainActivity, a.id))))
            p.addView(btn("＋ เพิ่มรายรับ") { addIncome(a) })
            if (a.mailFrom.isNotEmpty()) p.addView(btn("ดึงอีเมลใหม่") { syncMail(a, true) })
            Store.list(this, a.id).sortedByDescending { it.getLong("time") }.take(30).forEach { t ->
                val sign = if (t.getString("type") == "inc") "+" else "-"
                p.addView(tv(
                    String.format("\n%s น.\n%s%,.2f  %s %s", df.format(Date(t.getLong("time"))), sign, t.getDouble("amt"), t.optString("note"), t.optString("ref")).trimEnd()
                ))
            }
            root.addView(p)
        }

        val top = panel()
        top.addView(btn("เปิดสิทธิ์อ่านการแจ้งเตือน") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        top.addView(btn("ตั้งค่าอีเมล (Gmail + App Password)") {
            ask("อีเมล", "you@gmail.com") { u ->
                ask("App Password", "16 ตัวอักษร", pw = true) { p ->
                    val e = sp.edit().putString("mail_user", u).putString("mail_pw", p)
                    Config.accounts.filter { it.mailFrom.isNotEmpty() && !sp.contains("since_${it.id}") }
                        .forEach { e.putLong("since_${it.id}", System.currentTimeMillis()) }
                    e.apply()
                }
            }
        })
        top.addView(btn("ปรับแต่งหน้าตา (สี / รูปพื้นหลัง)") { customize() })
        root.addView(top)
    }
}
