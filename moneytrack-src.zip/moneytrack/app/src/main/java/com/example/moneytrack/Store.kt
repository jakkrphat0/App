package com.example.moneytrack

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("money", Context.MODE_PRIVATE)

    fun list(c: Context, id: String): List<JSONObject> {
        val a = JSONArray(sp(c).getString("tx_$id", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    @Synchronized
    fun add(c: Context, id: String, type: String, amt: Double, note: String, ref: String, time: Long): Boolean {
        val l = list(c, id)
        val dup = l.any {
            if (ref.isNotEmpty()) it.optString("ref") == ref
            else it.getString("type") == type && it.getDouble("amt") == amt && Math.abs(it.getLong("time") - time) < 60_000
        }
        if (dup) return false
        val a = JSONArray()
        l.forEach { a.put(it) }
        a.put(JSONObject().put("type", type).put("amt", amt).put("note", note).put("ref", ref).put("time", time))
        sp(c).edit().putString("tx_$id", a.toString()).apply()
        return true
    }

    fun open(c: Context, id: String) = sp(c).getString("open_$id", "0")?.toDoubleOrNull() ?: 0.0
    fun setOpen(c: Context, id: String, v: Double) = sp(c).edit().putString("open_$id", v.toString()).apply()

    fun balance(c: Context, id: String) =
        open(c, id) + list(c, id).sumOf { if (it.getString("type") == "inc") it.getDouble("amt") else -it.getDouble("amt") }
}
