package com.example.moneytrack

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        val all = "$title $text"
        val p = Parser.parse(all) ?: return
        for (a in Config.accounts) {
            if (sbn.packageName in a.notifPackages && (a.notifKeyword.isEmpty() || all.contains(a.notifKeyword, true))) {
                Store.add(this, a.id, p.type, p.amt, title.take(40), p.ref, sbn.postTime)
                break
            }
        }
    }
}
