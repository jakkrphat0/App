package com.example.moneytrack

// แก้ค่าตรงนี้ก่อนสร้างแอป
data class Acct(
    val id: String,
    val name: String,
    val notifPackages: List<String>, // แอปที่จะอ่านการแจ้งเตือน เช่น LINE หรือแอปธนาคาร
    val notifKeyword: String,        // คำที่ต้องมีในชื่อผู้ส่ง/ข้อความ เช่น "KBank" (ว่าง = รับทั้งหมดจากแอปนั้น)
    val mailFrom: String,            // อีเมลผู้ส่งของธนาคาร (ว่าง = ไม่ใช้อีเมล)
    val expenseOnly: Boolean = false // true = อีเมลบัญชีนี้มีแต่รายจ่าย (รายรับกดเพิ่มเอง)
)

object Config {
    val accounts = listOf(
        Acct("a", "Krungthai", listOf("jp.naver.line.android"), "Krungthai", ""),
        Acct("b", "Krungsri", emptyList(), "", "krungsri", expenseOnly = true)
    )
}
