package com.example.moneytrack

import android.content.Context
import java.util.Date
import java.util.Properties
import javax.mail.*
import javax.mail.search.AndTerm
import javax.mail.search.ComparisonTerm
import javax.mail.search.FromStringTerm
import javax.mail.search.ReceivedDateTerm

object MailSync {
    /**
     * ดึงเฉพาะอีเมลใหม่ที่เข้ามาหลังเริ่มติดตาม (ไม่อ่านย้อนหลัง) ผ่าน IMAP ของ Gmail (ต้องใช้ App Password)
     * คืนค่า: จำนวนรายการที่เพิ่ม, -1 = เชื่อมไม่สำเร็จ, ครั้งแรกจะเริ่มนับจากตอนนี้และคืน 0
     */
    fun sync(c: Context, a: Acct): Int {
        val sp = c.getSharedPreferences("money", Context.MODE_PRIVATE)
        val user = sp.getString("mail_user", "") ?: ""
        val pw = sp.getString("mail_pw", "") ?: ""
        if (user.isEmpty() || pw.isEmpty() || a.mailFrom.isEmpty()) return 0

        val key = "since_${a.id}" // ตรงกับที่ MainActivity ตั้งไว้ตอนบันทึกการตั้งค่าอีเมล
        val startedAt = System.currentTimeMillis()
        val since = sp.getLong(key, 0L)
        if (since == 0L) { // ครั้งแรก: เริ่มนับจากตอนนี้ ไม่ดึงของเก่า
            sp.edit().putLong(key, startedAt).apply()
            return 0
        }

        val store = Session.getInstance(Properties()).getStore("imaps")
        store.connect("imap.gmail.com", user, pw)
        val inbox = store.getFolder("INBOX")
        inbox.open(Folder.READ_ONLY)
        // IMAP ค้นตามวันที่ได้แค่ระดับวัน จึงกรองเวลาจริงอีกชั้น
        val msgs = inbox.search(AndTerm(FromStringTerm(a.mailFrom), ReceivedDateTerm(ComparisonTerm.GE, Date(since - 86_400_000))))
        var n = 0
        for (m in msgs) {
            val rt = m.receivedDate?.time ?: continue
            if (rt <= since) continue
            val subject = m.subject ?: ""
            val p = Parser.parse("$subject ${text(m)}") ?: continue
            if (a.expenseOnly && p.type == "inc") continue
            if (Store.add(c, a.id, p.type, p.amt, p.note.ifEmpty { subject }.take(40), p.ref, p.time ?: rt)) n++
        }
        inbox.close(false)
        store.close()
        sp.edit().putLong(key, startedAt - 120_000).apply() // เผื่อเวลาเหลื่อม กันซ้ำด้วยเลขอ้างอิง
        return n
    }

    private fun text(p: Part): String = when {
        p.isMimeType("text/plain") -> p.content as String
        p.isMimeType("text/html") -> (p.content as String)
            .replace(Regex("(?s)<style.*?</style>"), " ").replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ")
        p.isMimeType("multipart/*") -> {
            val mp = p.content as Multipart
            (0 until mp.count).joinToString(" ") { text(mp.getBodyPart(it)) }
        }
        else -> ""
    }
}
